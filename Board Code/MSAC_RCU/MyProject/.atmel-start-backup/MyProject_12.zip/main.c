#include <atmel_start.h>


static void tx_cb_UART(const struct usart_async_descriptor *const io_descr)
{
	/* Transfer completed */
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	static uint8_t example_UART[12] = "Hello World!";
	struct io_descriptor *io;

	usart_async_register_callback(&UART, USART_ASYNC_TXC_CB, tx_cb_UART);
	/*usart_async_register_callback(&UART, USART_ASYNC_RXC_CB, rx_cb);
	usart_async_register_callback(&UART, USART_ASYNC_ERROR_CB, err_cb);*/
	usart_async_get_io_descriptor(&UART, &io);
	usart_async_enable(&UART);
	while (1) {

		io_write(io, example_UART, 12);
	}
}

