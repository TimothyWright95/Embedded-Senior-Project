/*
 * mytasks.c
 *
 * Created: 4/27/2020 10:57:52 AM
 *  Author: yobro
 */ 
#include "mytasks.h"
#define TASK_STACK_SIZE (128 / sizeof(portSTACK_TYPE))
#define TASK_STACK_PRIORITY (tskIDLE_PRIORITY + 1)
static TaskHandle_t      xCreatedTask[10];
#define UNDOCK 0
#define DOCK 1
#define LEFT 0
#define RIGHT 1
#define OFF 2
//messages to send
#define BRUSH_ON 0
#define CONTINUE 0
#define MOVEDOWN 0

//responces
#define DONEMOVING 0
#define ALLDONE 0 
#define LOWBATTERY 0

void idle(int sf, int lb);
int check_sensors();
void dock(int dir);
void send_message(int msg);
int wait_for_responce();
void pwm(int dir);
int readbtn(int btn);
volatile int test_stop;

void UART_task(void *p)
{
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&UART, &io);
	usart_sync_enable(&UART);
	uint8_t data[24];
	int num = 0;
	(void)p;


	while(1)
	{
		if(usart_sync_is_rx_not_empty(io) !=0)
		{
			num = io_read(io, (uint8_t *)&data, 24);
		}
		if(num >0) io_write(io, (uint8_t *)&data, num);
		num = 0;
		os_sleep(2000);

	}
}
void PWM_task(void *p)
{
	//2000, 1333, 1000, 800, 667, 571, 500, 444, 400, 364, 333, 308, 286, 267, 250, 235, 222, 211, 200
	pwm_set_parameters(&StepperDriver, 1000, 500);
	test_stop = 0;
	while(1)
	{
		while(test_stop == 1);
		pwm_enable(&StepperDriver);
		//*
		pwm_ramp();
		while(test_stop == 0)
		{
			os_sleep(10);

		}

		
		pwm_disable(&StepperDriver);
	}
}
void BTN_task(void *p)
{
	while(1)
	{
		int btn1 = gpio_get_pin_level(Switch_1);	
		int btn2 = gpio_get_pin_level(Switch_2);
		if(btn1 == 0 || btn2 == 0) 
			test_stop = 1;
		else test_stop = 0;
		os_sleep(10);
	}
}

void STATE_task(void *p)
{
	int responce = 0;
	int sensor_failure = 0;
	int low_bat = 0;
	int continuing = 0;
	int done = 0;
	int dir = RIGHT;
	while(1)
	{
		idle(sensor_failure, low_bat);
		int sensor_failure = check_sensors();
		if(sensor_failure == 0)
		{
			dock(UNDOCK);
			send_message(BRUSH_ON);
			if(continuing)
			{
				send_message(CONTINUE);
				wait_for_responce();
			}
			while(done == 0)
			{
				pwm(dir);
				while(readbtn(dir) == 1 )
				{
					os_sleep(100);
				}
				pwm(OFF);
				send_message(MOVEDOWN);
				responce = wait_for_responce();
				if(responce == DONEMOVING)
				{
					if(dir == LEFT) dir = RIGHT;
					else dir = LEFT;
				}
				else if(responce == ALLDONE)
				{
					done = 1;
				}
				else if(responce == LOWBATTERY)
				{
					continuing = 1;
					dir = RIGHT;
					dock(DOCK);
				}
			}
		}
		
		
	}
	
	
}

void Create_all_tasks()
{
		/*if (xTaskCreate(
		UART_task, "UART", TASK_STACK_SIZE, NULL, TASK_STACK_PRIORITY, xCreatedTask[0])
		!= pdPASS) {
			while (1) {
				;
			}
		}
		if (xTaskCreate(
		PWM_task, "PWM", TASK_STACK_SIZE*10, NULL, TASK_STACK_PRIORITY, xCreatedTask[1])
		!= pdPASS) {
			while (1) {
				;
			}
		}
		if (xTaskCreate(
		BTN_task, "BTN", TASK_STACK_SIZE, NULL, TASK_STACK_PRIORITY, xCreatedTask[2])
		!= pdPASS) {
			while (1) {
				;
			}
		}
		/*if (xTaskCreate(
		STATE_task, "STATE", TASK_STACK_SIZE*20, NULL, TASK_STACK_PRIORITY, xCreatedTask[3])
		!= pdPASS) {
			while (1) {
				;
			}
		}	*/
		adc_sync_enable_channel(&TempSensor, 0);	
		while(1)
		{
			
			check_sensors();
		}
		vTaskStartScheduler();

		return;
}
void idle(int sf, int lb)//sf= sensor failure, lb = low battery
{
	//read button check for manual mode/start cleaning
	//check schedule
	//sleep 10
}
int check_sensors()
{
		uint8_t buffer[2];

		adc_sync_enable_channel(&TempSensor, 0);
		
		adc_sync_read_channel(&TempSensor, 0, buffer, 2);
		
		double to_return = ((uint16_t)buffer[1] << 8) | buffer[0];
		to_return = to_return * (3.3/4096.0) *1000;
		to_return = ( to_return - 500) / 10;
		return to_return;
}
void dock(int dir)
{
	
}
void send_message(int msg)
{
	
}
int wait_for_responce()
{
	return 0;
}
void pwm(int dir)
{
	
}
int readbtn(int btn)
{
	if(btn == RIGHT) return gpio_get_pin_level(Switch_1);
	else if(btn == LEFT) return gpio_get_pin_level(Switch_2);
	else return 0;
}
void pwm_ramp()
{
	int pwm_params[16] = {2000, 1333, 1000, 800, 667, 571, 500, 444, 400, 364, 333, 308, 286, 267, 250, 235};
		pwm_set_parameters(&StepperDriver, pwm_params[3], pwm_params[3]/2);
		os_sleep(10);
		pwm_set_parameters(&StepperDriver, pwm_params[4], pwm_params[4]/2);		
		os_sleep(10);
		pwm_set_parameters(&StepperDriver, pwm_params[5], pwm_params[5]/2);
		os_sleep(10);
		pwm_set_parameters(&StepperDriver, pwm_params[6], pwm_params[6]/2);
		os_sleep(10);
		pwm_set_parameters(&StepperDriver, pwm_params[7], pwm_params[7]/2);
		os_sleep(10);//*/
		pwm_set_parameters(&StepperDriver, pwm_params[8], pwm_params[8]/2);
		os_sleep(10);//*/
		pwm_set_parameters(&StepperDriver, pwm_params[9], pwm_params[9]/2);
}

