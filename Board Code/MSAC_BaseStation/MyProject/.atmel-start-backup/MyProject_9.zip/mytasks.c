/*
 * mytasks.c
 *
 * Created: 4/27/2020 10:57:52 AM
 *  Author: yobro
 */ 
#include "mytasks.h"
#define TASK_STACK_SIZE (128 / sizeof(portSTACK_TYPE))
#define TASK_STACK_PRIORITY (tskIDLE_PRIORITY + 1)
static TaskHandle_t      xCreatedTask;
static SemaphoreHandle_t disp_mutex;


void UART_task(void *p)
{
struct io_descriptor *io;
uint16_t              data;

(void)p;

usart_os_get_io(&UART, &io);
int i = 0;
int j = 0;
while(1)
{
	i = i+1;
	j = io->read(io, (uint8_t *)&data, 1);
	os_sleep(500);
}
}

void Create_all_tasks()
{
		

		if (xTaskCreate(
		UART_task, "Example", TASK_STACK_SIZE, NULL, TASK_STACK_PRIORITY, xCreatedTask)
		!= pdPASS) {
			while (1) {
				;
			}
		}

		vTaskStartScheduler();

		return;
}
