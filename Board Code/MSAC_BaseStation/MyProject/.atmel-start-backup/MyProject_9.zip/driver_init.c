/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>

/* The channel amount for ADC */
#define WINDSENSOR_CH_AMOUNT 1

/* The buffer size for ADC */
#define WINDSENSOR_BUFFER_SIZE 16

/* The maximal channel number of enabled channels */
#define WINDSENSOR_CH_MAX 0

/* The channel amount for ADC */
#define TEMPSENSOR_CH_AMOUNT 1

/* The buffer size for ADC */
#define TEMPSENSOR_BUFFER_SIZE 16

/* The maximal channel number of enabled channels */
#define TEMPSENSOR_CH_MAX 0

struct adc_os_descriptor         WindSensor;
struct adc_os_channel_descriptor WindSensor_ch[WINDSENSOR_CH_AMOUNT];
struct adc_os_descriptor         TempSensor;
struct adc_os_channel_descriptor TempSensor_ch[TEMPSENSOR_CH_AMOUNT];

static uint8_t WindSensor_buffer[WINDSENSOR_BUFFER_SIZE];
static uint8_t WindSensor_map[WINDSENSOR_CH_MAX + 1];
static uint8_t TempSensor_buffer[TEMPSENSOR_BUFFER_SIZE];
static uint8_t TempSensor_map[TEMPSENSOR_CH_MAX + 1];

struct calendar_os_descriptor Scheduler;

struct usart_os_descriptor UART;
uint8_t                    UART_buffer[UART_BUFFER_SIZE];

struct pwm_descriptor StepperDriver;

/**
 * \brief ADC initialization function
 *
 * Enables ADC peripheral, clocks and initializes ADC driver
 */
static void WindSensor_init(void)
{
	hri_mclk_set_APBCMASK_ADC0_bit(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, ADC0_GCLK_ID, CONF_GCLK_ADC0_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	adc_os_init(&WindSensor, ADC0, WindSensor_map, WINDSENSOR_CH_MAX, WINDSENSOR_CH_AMOUNT, &WindSensor_ch[0]);
	adc_os_register_channel_buffer(&WindSensor, 0, WindSensor_buffer, WINDSENSOR_BUFFER_SIZE);

	// Disable digital pin circuitry
	gpio_set_pin_direction(PB09, GPIO_DIRECTION_OFF);

	gpio_set_pin_function(PB09, PINMUX_PB09B_ADC0_AIN3);
}

/**
 * \brief ADC initialization function
 *
 * Enables ADC peripheral, clocks and initializes ADC driver
 */
static void TempSensor_init(void)
{
	hri_mclk_set_APBCMASK_ADC1_bit(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, ADC1_GCLK_ID, CONF_GCLK_ADC1_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	adc_os_init(&TempSensor, ADC1, TempSensor_map, TEMPSENSOR_CH_MAX, TEMPSENSOR_CH_AMOUNT, &TempSensor_ch[0]);
	adc_os_register_channel_buffer(&TempSensor, 0, TempSensor_buffer, TEMPSENSOR_BUFFER_SIZE);

	// Disable digital pin circuitry
	gpio_set_pin_direction(PA08, GPIO_DIRECTION_OFF);

	gpio_set_pin_function(PA08, PINMUX_PA08B_ADC1_AIN10);
}

void Scheduler_CLOCK_init(void)
{
	hri_mclk_set_APBAMASK_RTC_bit(MCLK);
}

void Scheduler_init(void)
{
	Scheduler_CLOCK_init();
	calendar_os_init(&Scheduler, RTC);
}

void UART_PORT_init(void)
{

	gpio_set_pin_function(PA22, PINMUX_PA22C_SERCOM3_PAD0);

	gpio_set_pin_function(PA23, PINMUX_PA23C_SERCOM3_PAD1);
}

void UART_CLOCK_init(void)
{
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM3_GCLK_ID_CORE, CONF_GCLK_SERCOM3_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM3_GCLK_ID_SLOW, CONF_GCLK_SERCOM3_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	hri_mclk_set_APBCMASK_SERCOM3_bit(MCLK);
}

void UART_init(void)
{

	UART_CLOCK_init();
	usart_os_init(&UART, SERCOM3, UART_buffer, UART_BUFFER_SIZE, (void *)NULL);
	usart_os_enable(&UART);
	UART_PORT_init();
}

void StepperDriver_PORT_init(void)
{

	gpio_set_pin_function(PB12, PINMUX_PB12E_TC0_WO0);
}

void StepperDriver_CLOCK_init(void)
{
	hri_mclk_set_APBCMASK_TC0_bit(MCLK);
	hri_gclk_write_PCHCTRL_reg(GCLK, TC0_GCLK_ID, CONF_GCLK_TC0_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
}

void StepperDriver_init(void)
{
	StepperDriver_CLOCK_init();
	StepperDriver_PORT_init();
	pwm_init(&StepperDriver, TC0, _tc_get_pwm());
}

void system_init(void)
{
	init_mcu();

	// GPIO on PA20

	// Set pin direction to input
	gpio_set_pin_direction(Switch_1, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(Switch_1,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_DOWN);

	gpio_set_pin_function(Switch_1, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PA21

	// Set pin direction to input
	gpio_set_pin_direction(Switch_2, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(Switch_2,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_DOWN);

	gpio_set_pin_function(Switch_2, GPIO_PIN_FUNCTION_OFF);

	WindSensor_init();
	TempSensor_init();

	Scheduler_init();

	UART_init();

	StepperDriver_init();
}
