/*
 * mytasks.c
 *
 * Created: 4/27/2020 10:57:52 AM
 *  Author: yobro
 */ 
#include "mytasks.h"
#define TASK_STACK_SIZE (128 / sizeof(portSTACK_TYPE))
#define TASK_STACK_PRIORITY (tskIDLE_PRIORITY + 1)
static TaskHandle_t      xCreatedTask[2];
static SemaphoreHandle_t disp_mutex;


void UART_task(void *p)
{
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&UART, &io);
	usart_sync_enable(&UART);
	uint8_t data[24];
	int num = 0;
	(void)p;


	while(1)
	{
		if(usart_sync_is_rx_not_empty(io) !=0)
		{
			num = io_read(io, (uint8_t *)&data, 24);
		}
		if(num >0) io_write(io, (uint8_t *)&data, num);
		num = 0;

	}
}
void PWM_task()
{
	pwm_set_parameters(&StepperDriver, 2, 1);
	pwm_enable(&StepperDriver);
	while(1);
}

void Create_all_tasks()
{
		

		if (xTaskCreate(
		UART_task, "UART", TASK_STACK_SIZE, NULL, TASK_STACK_PRIORITY, xCreatedTask[0])
		!= pdPASS) {
			while (1) {
				;
			}
		}
		if (xTaskCreate(
		PWM_task, "PWM", TASK_STACK_SIZE, NULL, TASK_STACK_PRIORITY, xCreatedTask[1])
		!= pdPASS) {
			while (1) {
				;
			}
		}
				

		vTaskStartScheduler();

		return;
}
