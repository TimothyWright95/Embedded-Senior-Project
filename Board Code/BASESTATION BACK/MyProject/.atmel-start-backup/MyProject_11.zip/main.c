#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
		struct io_descriptor *io;
		usart_sync_get_io_descriptor(&UART, &io);
		usart_sync_enable(&UART);
	/* Replace with your application code */
	uint8_t buf;
	while (1) {

		while(io_read(io,(uint8_t *)&buf,1) == 0);
		io_write(io, (uint8_t *)"Hello World!", 12);
	}
}
