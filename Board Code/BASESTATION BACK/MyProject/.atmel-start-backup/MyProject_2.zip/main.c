#include <atmel_start.h>
#include "driver_init.h"
#include "utils.h"
#include "mytasks.h"
#define TASK_STACK_SIZE (128 / sizeof(portSTACK_TYPE))
#define TASK_STACK_PRIORITY (tskIDLE_PRIORITY + 1)
static TaskHandle_t      xCreatedTask;
static SemaphoreHandle_t disp_mutex;


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	
	disp_mutex = xSemaphoreCreateMutex();

	if (disp_mutex == NULL) 
	{
		while (1) {;}
	}

	if (xTaskCreate(
		UART_task, 
		"UART_Echo_task", 
		TASK_STACK_SIZE, 
		NULL, 
		TASK_STACK_PRIORITY, 
		xCreatedTask)
		!= pdPASS) 
		{
			while (1) {;}
		}

	vTaskStartScheduler();


	/* Replace with your application code */
	while (1) {
		
		
		
		
	}
}
