/*
 * mytasks.c
 *
 * Created: 4/27/2020 10:57:52 AM
 *  Author: yobro
 */ 
#include "mytasks.h"
#define TASK_STACK_SIZE (128 / sizeof(portSTACK_TYPE))
#define TASK_STACK_PRIORITY (tskIDLE_PRIORITY + 1)
static TaskHandle_t      xCreatedTask;
static SemaphoreHandle_t disp_mutex;


void UART_task(void *p)
{
struct io_descriptor *io;
usart_sync_get_io_descriptor(&UART, &io);
usart_sync_enable(&UART);
uint8_t data;
int num = 0;
(void)p;


while(1)
{
	num = io_read(io, (uint8_t *)&data, 1);
	if(num >0) io_write(io, (uint8_t *)&data, 1);
	num = 0;
	os_sleep(1000);
}
}

void Create_all_tasks()
{
		

		if (xTaskCreate(
		UART_task, "Example", TASK_STACK_SIZE, NULL, TASK_STACK_PRIORITY, xCreatedTask)
		!= pdPASS) {
			while (1) {
				;
			}
		}

		vTaskStartScheduler();

		return;
}
