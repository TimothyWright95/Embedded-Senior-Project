#include <atmel_start.h>
#include "mytasks.h"
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    //Create_all_tasks();
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&UART, &io);
	usart_sync_enable(&UART);
	uint8_t recv_char;
	int data_arrived =0;
	/* Replace with your application code */
	while (1) 
	{
		if (data_arrived == 0) 
		{
			//continue;
		}
		while (io_read(io, &recv_char, 1) == 1) 
		{
			while (io_write(io, &recv_char, 1) != 1) 
			{}
		}
		data_arrived = 0;
	
	}
}
